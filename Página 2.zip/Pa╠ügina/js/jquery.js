$(document).ready(function(){
    
    var paginaAboutUs = 1;

    function rotadorAboutUs(){
        if (paginaAboutUs === 1){
            $("#filosofy").hide();
            $("#transform").fadeIn();
            paginaAboutUs++;
            /* console.log(pagina); */
        }
        else if (paginaAboutUs === 2){
            $("#transform").hide();
            $("#filosofy").fadeIn();
            paginaAboutUs--;
        }
    };

    function rotadorServiciosDer(){
        if(paginaServices === 1){
            $("#automatizacion").hide();
            $("#rendimiento").fadeIn();
            paginaServices++;
        }
        else if (paginaServices === 2){
            $("#rendimiento").hide();
            $("#estrategia").fadeIn();
            paginaServices++;
        }

        else if (paginaServices === 3){
            $("#estrategia").hide();
            $("#tecnologia").fadeIn();
            paginaServices++;
        }
        else if (paginaServices === 4){
            $("#tecnologia").hide();
            $("#demanda").fadeIn();
            paginaServices++;
        }

        else if (paginaServices === 5){
            $("#demanda").hide();
            $("#automatizacion").fadeIn();
            paginaServices = 1;
        }

    };

    function rotadorServiciosIzq(){

        if(paginaServices === 1){
            $("#automatizacion").hide();
            $("#demanda").fadeIn();
            paginaServices = 5;
        }

        else if (paginaServices === 5){
            $("#demanda").hide();
            $("#tecnologia").fadeIn();
            paginaServices--;
        }

        else if (paginaServices === 4){
            $("#tecnologia").hide();
            $("#estrategia").fadeIn();
            paginaServices--;
        }

        else if (paginaServices === 3){
            $("#estrategia").hide();
            $("#rendimiento").fadeIn();
            paginaServices--;
        }

        else if (paginaServices === 2){
            $("#rendimiento").hide();
            $("#automatizacion").fadeIn();
            paginaServices--;
        }
        

    };


    $("#transform").hide();

    $("#rendimiento").hide();
    $("#estrategia").hide();
    $("#tecnologia").hide();
    $("#demanda").hide();

    $("#button_short_rigth").click(rotadorAboutUs);
    $("#button_short_left").click(rotadorAboutUs);

    /* ANIMACIÓN SERVICIOS */

    var paginaServices = 1;

    $("#button_short_rigth_services").click(rotadorServiciosDer);
    $("#button_short_left_services").click(rotadorServiciosIzq);

    
    /* ANIMACIÓN INDUSTRIAS */
    var anchoPantalla = screen.width;

    if (anchoPantalla < 528) {

        let IndustryItems = $(".section-industrias .industria_content").length;
        console.log(IndustryItems);

        /* agregar paginación */
        for (i = 1; i<= IndustryItems; i++ ){
            $('.pagination').append('<li><i class="fa-regular fa-circle"></i></li>');
        }
        //--------------------------

        $('.industria_content').hide();
        $('.industria_content:nth-child(2)').show();

        $('#pagination li').click(pagination);

        function pagination(){
            var paginationPos = $(this).index()+2;
            console.log(paginationPos);
            $('.industria_content').hide();
            $('.industria_content:nth-child('+ paginationPos +')').fadeIn();
        }
    }
    else {

        $("#industria1").hover(function(){
            $("#industria1 button").toggle(500);
        });

        $("#industria2").hover(function(){
            $("#industria2 button").toggle(500);
        });
        $("#industria3").hover(function(){
            $("#industria3 button").toggle(500);
        });
        $("#industria4").hover(function(){
            $("#industria4 button").toggle(500);
        });
        $("#industria5").hover(function(){
            $("#industria5 button").toggle(500);
        });
    
    }

    /* HISTORIAS DE ÉXITO */

    $('.historias_de_exito').hide();
    $('#button_historias').click(function(){
        $('.historias_de_exito').toggle(500);
    });

    /* FORMULARIO HOME */
    $('#form_home_container').hide();
    $('#button_form_home').click(function(){
        $('#form_home_container').toggle(500);
    });
});

function enviarForm(){
    alert("formulario enviado");
}








